"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/[[...catchall]]";
exports.ids = ["pages/[[...catchall]]"];
exports.modules = {

/***/ "./pages/[[...catchall]].tsx":
/*!***********************************!*\
  !*** ./pages/[[...catchall]].tsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ PlasmicLoaderPage),\n/* harmony export */   \"getStaticPaths\": () => (/* binding */ getStaticPaths),\n/* harmony export */   \"getStaticProps\": () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @plasmicapp/loader-nextjs */ \"@plasmicapp/loader-nextjs\");\n/* harmony import */ var _plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/error */ \"next/error\");\n/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_error__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _plasmic_init__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../plasmic-init */ \"./plasmic-init.ts\");\n\n\n\n\n\n\nfunction PlasmicLoaderPage(props) {\n    const { plasmicData , queryCache  } = props;\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();\n    if (!plasmicData || plasmicData.entryCompMetas.length === 0) {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_error__WEBPACK_IMPORTED_MODULE_3___default()), {\n            statusCode: 404\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Rana G\\\\Desktop\\\\Furniture-E-Comrese\\\\Furn-E-commerce-Website-First-Page-main\\\\pages\\\\[[...catchall]].tsx\",\n            lineNumber: 21,\n            columnNumber: 12\n        }, this);\n    }\n    const pageMeta = plasmicData.entryCompMetas[0];\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__.PlasmicRootProvider, {\n        loader: _plasmic_init__WEBPACK_IMPORTED_MODULE_5__.PLASMIC,\n        prefetchedData: plasmicData,\n        prefetchedQueryData: queryCache,\n        pageParams: pageMeta.params,\n        pageQuery: router.query,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__.PlasmicComponent, {\n            component: pageMeta.displayName\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Rana G\\\\Desktop\\\\Furniture-E-Comrese\\\\Furn-E-commerce-Website-First-Page-main\\\\pages\\\\[[...catchall]].tsx\",\n            lineNumber: 32,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Rana G\\\\Desktop\\\\Furniture-E-Comrese\\\\Furn-E-commerce-Website-First-Page-main\\\\pages\\\\[[...catchall]].tsx\",\n        lineNumber: 25,\n        columnNumber: 5\n    }, this);\n}\nconst getStaticProps = async (context)=>{\n    const { catchall  } = context.params ?? {};\n    const plasmicPath = typeof catchall === \"string\" ? catchall : Array.isArray(catchall) ? `/${catchall.join(\"/\")}` : \"/\";\n    const plasmicData = await _plasmic_init__WEBPACK_IMPORTED_MODULE_5__.PLASMIC.maybeFetchComponentData(plasmicPath);\n    if (!plasmicData) {\n        // non-Plasmic catch-all\n        return {\n            props: {}\n        };\n    }\n    const pageMeta = plasmicData.entryCompMetas[0];\n    // Cache the necessary data fetched for the page\n    const queryCache = await (0,_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__.extractPlasmicQueryData)(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__.PlasmicRootProvider, {\n        loader: _plasmic_init__WEBPACK_IMPORTED_MODULE_5__.PLASMIC,\n        prefetchedData: plasmicData,\n        pageParams: pageMeta.params,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_2__.PlasmicComponent, {\n            component: pageMeta.displayName\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Rana G\\\\Desktop\\\\Furniture-E-Comrese\\\\Furn-E-commerce-Website-First-Page-main\\\\pages\\\\[[...catchall]].tsx\",\n            lineNumber: 53,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Rana G\\\\Desktop\\\\Furniture-E-Comrese\\\\Furn-E-commerce-Website-First-Page-main\\\\pages\\\\[[...catchall]].tsx\",\n        lineNumber: 48,\n        columnNumber: 5\n    }, undefined));\n    // Use revalidate if you want incremental static regeneration\n    return {\n        props: {\n            plasmicData,\n            queryCache\n        },\n        revalidate: 60\n    };\n};\nconst getStaticPaths = async ()=>{\n    const pageModules = await _plasmic_init__WEBPACK_IMPORTED_MODULE_5__.PLASMIC.fetchPages();\n    return {\n        paths: pageModules.map((mod)=>({\n                params: {\n                    catchall: mod.path.substring(1).split(\"/\")\n                }\n            })),\n        fallback: \"blocking\"\n    };\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9bWy4uLmNhdGNoYWxsXV0udHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUErQjtBQU1JO0FBR0o7QUFDUztBQUNFO0FBRTNCLFNBQVNPLGtCQUFrQkMsS0FHekMsRUFBRTtJQUNELE1BQU0sRUFBRUMsWUFBVyxFQUFFQyxXQUFVLEVBQUUsR0FBR0Y7SUFDcEMsTUFBTUcsU0FBU04sc0RBQVNBO0lBQ3hCLElBQUksQ0FBQ0ksZUFBZUEsWUFBWUcsY0FBYyxDQUFDQyxNQUFNLEtBQUssR0FBRztRQUMzRCxxQkFBTyw4REFBQ1QsbURBQUtBO1lBQUNVLFlBQVk7Ozs7OztJQUM1QixDQUFDO0lBQ0QsTUFBTUMsV0FBV04sWUFBWUcsY0FBYyxDQUFDLEVBQUU7SUFDOUMscUJBQ0UsOERBQUNULDBFQUFtQkE7UUFDbEJhLFFBQVFWLGtEQUFPQTtRQUNmVyxnQkFBZ0JSO1FBQ2hCUyxxQkFBcUJSO1FBQ3JCUyxZQUFZSixTQUFTSyxNQUFNO1FBQzNCQyxXQUFXVixPQUFPVyxLQUFLO2tCQUV2Qiw0RUFBQ3JCLHVFQUFnQkE7WUFBQ3NCLFdBQVdSLFNBQVNTLFdBQVc7Ozs7Ozs7Ozs7O0FBR3ZELENBQUM7QUFFTSxNQUFNQyxpQkFBaUMsT0FBT0MsVUFBWTtJQUMvRCxNQUFNLEVBQUVDLFNBQVEsRUFBRSxHQUFHRCxRQUFRTixNQUFNLElBQUksQ0FBQztJQUN4QyxNQUFNUSxjQUFjLE9BQU9ELGFBQWEsV0FBV0EsV0FBV0UsTUFBTUMsT0FBTyxDQUFDSCxZQUFZLENBQUMsQ0FBQyxFQUFFQSxTQUFTSSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRztJQUN0SCxNQUFNdEIsY0FBYyxNQUFNSCwwRUFBK0IsQ0FBQ3NCO0lBQzFELElBQUksQ0FBQ25CLGFBQWE7UUFDaEIsd0JBQXdCO1FBQ3hCLE9BQU87WUFBRUQsT0FBTyxDQUFDO1FBQUU7SUFDckIsQ0FBQztJQUNELE1BQU1PLFdBQVdOLFlBQVlHLGNBQWMsQ0FBQyxFQUFFO0lBQzlDLGdEQUFnRDtJQUNoRCxNQUFNRixhQUFhLE1BQU1SLGtGQUF1QkEsZUFDOUMsOERBQUNDLDBFQUFtQkE7UUFDbEJhLFFBQVFWLGtEQUFPQTtRQUNmVyxnQkFBZ0JSO1FBQ2hCVSxZQUFZSixTQUFTSyxNQUFNO2tCQUUzQiw0RUFBQ25CLHVFQUFnQkE7WUFBQ3NCLFdBQVdSLFNBQVNTLFdBQVc7Ozs7Ozs7Ozs7O0lBR3JELDZEQUE2RDtJQUM3RCxPQUFPO1FBQUVoQixPQUFPO1lBQUVDO1lBQWFDO1FBQVc7UUFBR3VCLFlBQVk7SUFBRztBQUM5RCxFQUFDO0FBRU0sTUFBTUMsaUJBQWlDLFVBQVk7SUFDeEQsTUFBTUMsY0FBYyxNQUFNN0IsNkRBQWtCO0lBQzVDLE9BQU87UUFDTCtCLE9BQU9GLFlBQVlHLEdBQUcsQ0FBQyxDQUFDQyxNQUFTO2dCQUMvQm5CLFFBQVE7b0JBQ05PLFVBQVVZLElBQUlDLElBQUksQ0FBQ0MsU0FBUyxDQUFDLEdBQUdDLEtBQUssQ0FBQztnQkFDeEM7WUFDRjtRQUNBQyxVQUFVO0lBQ1o7QUFDRixFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdG1wLWNwYS8uL3BhZ2VzL1tbLi4uY2F0Y2hhbGxdXS50c3g/NTczZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIFBsYXNtaWNDb21wb25lbnQsXG4gIGV4dHJhY3RQbGFzbWljUXVlcnlEYXRhLFxuICBDb21wb25lbnRSZW5kZXJEYXRhLFxuICBQbGFzbWljUm9vdFByb3ZpZGVyLFxufSBmcm9tIFwiQHBsYXNtaWNhcHAvbG9hZGVyLW5leHRqc1wiO1xuaW1wb3J0IHR5cGUgeyBHZXRTdGF0aWNQYXRocywgR2V0U3RhdGljUHJvcHMgfSBmcm9tIFwibmV4dFwiO1xuXG5pbXBvcnQgRXJyb3IgZnJvbSBcIm5leHQvZXJyb3JcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgUExBU01JQyB9IGZyb20gXCIuLi9wbGFzbWljLWluaXRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGxhc21pY0xvYWRlclBhZ2UocHJvcHM6IHtcbiAgcGxhc21pY0RhdGE/OiBDb21wb25lbnRSZW5kZXJEYXRhO1xuICBxdWVyeUNhY2hlPzogUmVjb3JkPHN0cmluZywgYW55Pjtcbn0pIHtcbiAgY29uc3QgeyBwbGFzbWljRGF0YSwgcXVlcnlDYWNoZSB9ID0gcHJvcHM7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICBpZiAoIXBsYXNtaWNEYXRhIHx8IHBsYXNtaWNEYXRhLmVudHJ5Q29tcE1ldGFzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiA8RXJyb3Igc3RhdHVzQ29kZT17NDA0fSAvPjtcbiAgfVxuICBjb25zdCBwYWdlTWV0YSA9IHBsYXNtaWNEYXRhLmVudHJ5Q29tcE1ldGFzWzBdO1xuICByZXR1cm4gKFxuICAgIDxQbGFzbWljUm9vdFByb3ZpZGVyXG4gICAgICBsb2FkZXI9e1BMQVNNSUN9XG4gICAgICBwcmVmZXRjaGVkRGF0YT17cGxhc21pY0RhdGF9XG4gICAgICBwcmVmZXRjaGVkUXVlcnlEYXRhPXtxdWVyeUNhY2hlfVxuICAgICAgcGFnZVBhcmFtcz17cGFnZU1ldGEucGFyYW1zfVxuICAgICAgcGFnZVF1ZXJ5PXtyb3V0ZXIucXVlcnl9XG4gICAgPlxuICAgICAgPFBsYXNtaWNDb21wb25lbnQgY29tcG9uZW50PXtwYWdlTWV0YS5kaXNwbGF5TmFtZX0gLz5cbiAgICA8L1BsYXNtaWNSb290UHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQcm9wczogR2V0U3RhdGljUHJvcHMgPSBhc3luYyAoY29udGV4dCkgPT4ge1xuICBjb25zdCB7IGNhdGNoYWxsIH0gPSBjb250ZXh0LnBhcmFtcyA/PyB7fTtcbiAgY29uc3QgcGxhc21pY1BhdGggPSB0eXBlb2YgY2F0Y2hhbGwgPT09ICdzdHJpbmcnID8gY2F0Y2hhbGwgOiBBcnJheS5pc0FycmF5KGNhdGNoYWxsKSA/IGAvJHtjYXRjaGFsbC5qb2luKCcvJyl9YCA6ICcvJztcbiAgY29uc3QgcGxhc21pY0RhdGEgPSBhd2FpdCBQTEFTTUlDLm1heWJlRmV0Y2hDb21wb25lbnREYXRhKHBsYXNtaWNQYXRoKTtcbiAgaWYgKCFwbGFzbWljRGF0YSkge1xuICAgIC8vIG5vbi1QbGFzbWljIGNhdGNoLWFsbFxuICAgIHJldHVybiB7IHByb3BzOiB7fSB9O1xuICB9XG4gIGNvbnN0IHBhZ2VNZXRhID0gcGxhc21pY0RhdGEuZW50cnlDb21wTWV0YXNbMF07XG4gIC8vIENhY2hlIHRoZSBuZWNlc3NhcnkgZGF0YSBmZXRjaGVkIGZvciB0aGUgcGFnZVxuICBjb25zdCBxdWVyeUNhY2hlID0gYXdhaXQgZXh0cmFjdFBsYXNtaWNRdWVyeURhdGEoXG4gICAgPFBsYXNtaWNSb290UHJvdmlkZXJcbiAgICAgIGxvYWRlcj17UExBU01JQ31cbiAgICAgIHByZWZldGNoZWREYXRhPXtwbGFzbWljRGF0YX1cbiAgICAgIHBhZ2VQYXJhbXM9e3BhZ2VNZXRhLnBhcmFtc31cbiAgICA+XG4gICAgICA8UGxhc21pY0NvbXBvbmVudCBjb21wb25lbnQ9e3BhZ2VNZXRhLmRpc3BsYXlOYW1lfSAvPlxuICAgIDwvUGxhc21pY1Jvb3RQcm92aWRlcj5cbiAgKTtcbiAgLy8gVXNlIHJldmFsaWRhdGUgaWYgeW91IHdhbnQgaW5jcmVtZW50YWwgc3RhdGljIHJlZ2VuZXJhdGlvblxuICByZXR1cm4geyBwcm9wczogeyBwbGFzbWljRGF0YSwgcXVlcnlDYWNoZSB9LCByZXZhbGlkYXRlOiA2MCB9O1xufVxuXG5leHBvcnQgY29uc3QgZ2V0U3RhdGljUGF0aHM6IEdldFN0YXRpY1BhdGhzID0gYXN5bmMgKCkgPT4ge1xuICBjb25zdCBwYWdlTW9kdWxlcyA9IGF3YWl0IFBMQVNNSUMuZmV0Y2hQYWdlcygpO1xuICByZXR1cm4ge1xuICAgIHBhdGhzOiBwYWdlTW9kdWxlcy5tYXAoKG1vZCkgPT4gKHtcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBjYXRjaGFsbDogbW9kLnBhdGguc3Vic3RyaW5nKDEpLnNwbGl0KFwiL1wiKSxcbiAgICAgIH0sXG4gICAgfSkpLFxuICAgIGZhbGxiYWNrOiBcImJsb2NraW5nXCIsXG4gIH07XG59Il0sIm5hbWVzIjpbIlJlYWN0IiwiUGxhc21pY0NvbXBvbmVudCIsImV4dHJhY3RQbGFzbWljUXVlcnlEYXRhIiwiUGxhc21pY1Jvb3RQcm92aWRlciIsIkVycm9yIiwidXNlUm91dGVyIiwiUExBU01JQyIsIlBsYXNtaWNMb2FkZXJQYWdlIiwicHJvcHMiLCJwbGFzbWljRGF0YSIsInF1ZXJ5Q2FjaGUiLCJyb3V0ZXIiLCJlbnRyeUNvbXBNZXRhcyIsImxlbmd0aCIsInN0YXR1c0NvZGUiLCJwYWdlTWV0YSIsImxvYWRlciIsInByZWZldGNoZWREYXRhIiwicHJlZmV0Y2hlZFF1ZXJ5RGF0YSIsInBhZ2VQYXJhbXMiLCJwYXJhbXMiLCJwYWdlUXVlcnkiLCJxdWVyeSIsImNvbXBvbmVudCIsImRpc3BsYXlOYW1lIiwiZ2V0U3RhdGljUHJvcHMiLCJjb250ZXh0IiwiY2F0Y2hhbGwiLCJwbGFzbWljUGF0aCIsIkFycmF5IiwiaXNBcnJheSIsImpvaW4iLCJtYXliZUZldGNoQ29tcG9uZW50RGF0YSIsInJldmFsaWRhdGUiLCJnZXRTdGF0aWNQYXRocyIsInBhZ2VNb2R1bGVzIiwiZmV0Y2hQYWdlcyIsInBhdGhzIiwibWFwIiwibW9kIiwicGF0aCIsInN1YnN0cmluZyIsInNwbGl0IiwiZmFsbGJhY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/[[...catchall]].tsx\n");

/***/ }),

/***/ "./plasmic-init.ts":
/*!*************************!*\
  !*** ./plasmic-init.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"PLASMIC\": () => (/* binding */ PLASMIC)\n/* harmony export */ });\n/* harmony import */ var _plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plasmicapp/loader-nextjs */ \"@plasmicapp/loader-nextjs\");\n/* harmony import */ var _plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_0__);\n\nconst PLASMIC = (0,_plasmicapp_loader_nextjs__WEBPACK_IMPORTED_MODULE_0__.initPlasmicLoader)({\n    projects: [\n        {\n            id: \"bvFLSf9oyyrrHHSD5c3qVt\",\n            token: \"VM5beYoSWNxLM1e0cpcemKEm32Cg32Ra04mcIQskp2lavKtiVtpbqv9hiWOYvUmQGUQGvljMXrZH4c9sA\"\n        }\n    ],\n    // By default Plasmic will use the last published version of your project.\n    // For development, you can set preview to true, which will use the unpublished\n    // project, allowing you to see your designs without publishing.  Please\n    // only use this for development, as this is significantly slower.\n    preview: false\n}); // You can register any code components that you want to use here; see\n // https://docs.plasmic.app/learn/code-components-ref/\n // And configure your Plasmic project to use the host url pointing at\n // the /plasmic-host page of your nextjs app (for example,\n // http://localhost:3000/plasmic-host).  See\n // https://docs.plasmic.app/learn/app-hosting/#set-a-plasmic-project-to-use-your-app-host\n // PLASMIC.registerComponent(...);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wbGFzbWljLWluaXQudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQThEO0FBRXZELE1BQU1DLFVBQVVELDRFQUFpQkEsQ0FBQztJQUN2Q0UsVUFBVTtRQUNSO1lBQ0VDLElBQUk7WUFDSkMsT0FBTztRQUNUO0tBQ0Q7SUFFRCwwRUFBMEU7SUFDMUUsK0VBQStFO0lBQy9FLHdFQUF3RTtJQUN4RSxrRUFBa0U7SUFDbEVDLFNBQVMsS0FBSztBQUNoQixHQUFHLENBRUgsc0VBQXNFO0NBQ3RFLHNEQUFzRDtDQUN0RCxxRUFBcUU7Q0FDckUsMERBQTBEO0NBQzFELDRDQUE0QztDQUM1Qyx5RkFBeUY7Q0FFekYsa0NBQWtDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdG1wLWNwYS8uL3BsYXNtaWMtaW5pdC50cz85MDZmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGluaXRQbGFzbWljTG9hZGVyIH0gZnJvbSBcIkBwbGFzbWljYXBwL2xvYWRlci1uZXh0anNcIjtcblxuZXhwb3J0IGNvbnN0IFBMQVNNSUMgPSBpbml0UGxhc21pY0xvYWRlcih7XG4gIHByb2plY3RzOiBbXG4gICAge1xuICAgICAgaWQ6IFwiYnZGTFNmOW95eXJySEhTRDVjM3FWdFwiLFxuICAgICAgdG9rZW46IFwiVk01YmVZb1NXTnhMTTFlMGNwY2VtS0VtMzJDZzMyUmEwNG1jSVFza3AybGF2S3RpVnRwYnF2OWhpV09ZdlVtUUdVUUd2bGpNWHJaSDRjOXNBXCIsXG4gICAgfSxcbiAgXSxcblxuICAvLyBCeSBkZWZhdWx0IFBsYXNtaWMgd2lsbCB1c2UgdGhlIGxhc3QgcHVibGlzaGVkIHZlcnNpb24gb2YgeW91ciBwcm9qZWN0LlxuICAvLyBGb3IgZGV2ZWxvcG1lbnQsIHlvdSBjYW4gc2V0IHByZXZpZXcgdG8gdHJ1ZSwgd2hpY2ggd2lsbCB1c2UgdGhlIHVucHVibGlzaGVkXG4gIC8vIHByb2plY3QsIGFsbG93aW5nIHlvdSB0byBzZWUgeW91ciBkZXNpZ25zIHdpdGhvdXQgcHVibGlzaGluZy4gIFBsZWFzZVxuICAvLyBvbmx5IHVzZSB0aGlzIGZvciBkZXZlbG9wbWVudCwgYXMgdGhpcyBpcyBzaWduaWZpY2FudGx5IHNsb3dlci5cbiAgcHJldmlldzogZmFsc2UsXG59KTtcblxuLy8gWW91IGNhbiByZWdpc3RlciBhbnkgY29kZSBjb21wb25lbnRzIHRoYXQgeW91IHdhbnQgdG8gdXNlIGhlcmU7IHNlZVxuLy8gaHR0cHM6Ly9kb2NzLnBsYXNtaWMuYXBwL2xlYXJuL2NvZGUtY29tcG9uZW50cy1yZWYvXG4vLyBBbmQgY29uZmlndXJlIHlvdXIgUGxhc21pYyBwcm9qZWN0IHRvIHVzZSB0aGUgaG9zdCB1cmwgcG9pbnRpbmcgYXRcbi8vIHRoZSAvcGxhc21pYy1ob3N0IHBhZ2Ugb2YgeW91ciBuZXh0anMgYXBwIChmb3IgZXhhbXBsZSxcbi8vIGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wbGFzbWljLWhvc3QpLiAgU2VlXG4vLyBodHRwczovL2RvY3MucGxhc21pYy5hcHAvbGVhcm4vYXBwLWhvc3RpbmcvI3NldC1hLXBsYXNtaWMtcHJvamVjdC10by11c2UteW91ci1hcHAtaG9zdFxuXG4vLyBQTEFTTUlDLnJlZ2lzdGVyQ29tcG9uZW50KC4uLik7Il0sIm5hbWVzIjpbImluaXRQbGFzbWljTG9hZGVyIiwiUExBU01JQyIsInByb2plY3RzIiwiaWQiLCJ0b2tlbiIsInByZXZpZXciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./plasmic-init.ts\n");

/***/ }),

/***/ "@plasmicapp/loader-nextjs":
/*!********************************************!*\
  !*** external "@plasmicapp/loader-nextjs" ***!
  \********************************************/
/***/ ((module) => {

module.exports = require("@plasmicapp/loader-nextjs");

/***/ }),

/***/ "next/error":
/*!*****************************!*\
  !*** external "next/error" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/[[...catchall]].tsx"));
module.exports = __webpack_exports__;

})();